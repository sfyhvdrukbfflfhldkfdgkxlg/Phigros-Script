
package android.os;
public class SystemClock {
 public static long now=100000;
 public static long uptimeMillis(){return now++;}
 public static void sleep(long ms){now+=ms;}
}
